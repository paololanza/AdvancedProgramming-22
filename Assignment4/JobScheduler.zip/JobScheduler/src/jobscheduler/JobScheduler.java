/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jobscheduler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/**
 *
 * @author paololanza
 */
public abstract class JobScheduler<K, V> {

    public JobScheduler(){
        
    }
    
    //frozen spot that runs the template
    public final void run()
    {
        //function that emits a Stream of AJob object
        Stream<AJob<K, V>> inputStream = emit();

        //function that given a Stream of AJob object returns a Stream of Pair 
        Stream<Pair<K, V>> execStream = compute(inputStream);

        //function that given a Stream of Pair returns a Stream of grouped Pair
        Stream<Pair<K, List<V>>> groupedStream = collect(execStream);

        //function that given a Stream of grouped pair it output the results
        output(groupedStream);
    }
    
    /*
    Hot spot of the framework that emit a Stream of AJob 
     */
    protected abstract Stream<AJob<K,V>> emit();
    
    /*
    Frozen spot that given a Stream of AJob, it executes AJobs and returns a 
    stream of Pair returned by the execution of the AJobs.
    */
    private Stream<Pair<K,V>> compute(Stream<AJob<K,V>> jobs)
    {
        ArrayList<Pair<K, V>> streamList = new ArrayList();
        
        jobs.forEach(j -> {
            Stream<Pair<K, V>> l = j.execute();
            l.forEach(item -> {
                streamList.add(item);
            });
        });
        
        return streamList.stream();
    }
    
    /*
    Frozen spot that given a Stream of Pair, it grouped Pair with the same Key
    and returns a Stream of grouped Pair
    */
    private Stream<Pair<K, List<V>>> collect(Stream<Pair<K,V>> exec)
    {
        Map<K, List<V>> groupedMap = new HashMap<>();

        exec.forEach(e -> {

          if (!groupedMap.containsKey(e.getKey()))
            groupedMap.put(e.getKey(), new ArrayList<>());

          groupedMap.get(e.getKey()).add(e.getValue());

        });
        
        return groupedMap.entrySet().stream().map(x -> new Pair<>(x.getKey(), x.getValue()));
    }
    
    /*
    Hot spot of the framework that outputs the result of the whole computation
    */
    protected abstract void output(Stream<Pair<K, List<V>>> jobs);
    
}
