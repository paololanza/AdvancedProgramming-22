/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jobscheduler;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

/**
 *
 * @author paololanza
 */
public class Task extends AJob<String, String>{
    
    private String filename = new String();
    
    public Task(String file)
    {
        this.filename = file;
    }
    
    //compute the ciao of the string given as parameter
    private String ciao(String s)
    {
        String ciao = s.toLowerCase();
        char[] cArray = ciao.toCharArray();
        Arrays.sort(cArray);
        
        String ret = new String(cArray);
        return ret;
    }

    /*
    Concrete implementation of the execute method of the template AJob. 
    It takes the filename and returns a Stream of Pair where the key is the ciao 
    string of the word and the value is the original word.
    */
    @Override
    public Stream<Pair<String, String>> execute() 
    {
        Map<String, String> mapper = new HashMap<>();
        try
        {
            File file = new File(filename);
            Scanner scanner = new Scanner(file);
            
            System.out.println("Scanning the file " + file.getName() + ": ");

            while(scanner.hasNextLine())
            {
                String line = scanner.nextLine();
                String[] words = line.split(" ");
                for(String word : words)
                {
                    //formatting the word
                    word = word.replaceAll("[^a-zA-Z]", "");
                    word = word.toLowerCase();
                    
                    //ignore words that are length less than 4
                    if(word.length() > 3)
                    {
                        mapper.put(ciao(word), word);
                    }
                }
            }
            scanner.close();

        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
        
        return mapper.entrySet().stream().map(x -> new Pair<>(x.getKey(), x.getValue()));
    }
    
}
