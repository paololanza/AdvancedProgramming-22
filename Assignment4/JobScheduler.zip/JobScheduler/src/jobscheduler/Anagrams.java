/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jobscheduler;

import java.io.Console;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;

/**
 *
 * @author paololanza
 */
public class Anagrams extends JobScheduler<String, String>{
    
    public Anagrams()
    {
        
    }

    /*
    Concrete impelementation of the emit function of the template. It take as
    input a path of a directory that contains text file. The function for each
    text file creates an instance of AJob and return the Stream of AJob created.
    */
    @Override
    protected Stream<AJob<String, String>> emit() {
        
        //declare an ArrayList that contains AJob instances
        ArrayList<AJob<String, String>> taskList = new ArrayList();
        
        System.out.println("Insert the directory path: ");
        Scanner scanner = new Scanner(System.in);
        String filename = scanner.next();
      
        //creating a task for each file contained into the directory
        File file = new File(filename);
        File[] contents = file.listFiles();
        for(File doc : contents)
        {
            int index = doc.getName().lastIndexOf(".");
            if(doc.getName().substring(index).equals(".txt"))
            {
                Task task = new Task(doc.getAbsolutePath());
                taskList.add(task);
            }
            
        }
        
        return taskList.stream();
    }

    /*
    Concrete impelementation of the output function of the template. It takes as
    parameter a Stream of grouped Pair. It creates a file that will contains the
    output of the template and for each Pair writes in the file the key and the
    number of element associated with that key. 
    */
    @Override
    protected void output(Stream<Pair<String, List<String>>> jobs) {
        try
        {
            //creating the output file if it doesn't exist
            File outFile = new File ("count_anagrams.txt");
            if (!outFile.exists()) 
            {
                outFile.createNewFile();
            }

            //for each pair contained in the stream parse and write the line in
            //the file
            FileWriter writer = new FileWriter(outFile.getAbsolutePath());
            jobs.forEach(item -> {
                String line = item.getKey() + " - " + item.getValue().size();
                try 
                {
                    writer.write(line + "\n");
                } 
                catch (IOException ex) 
                {
                    Logger.getLogger(Anagrams.class.getName()).log(Level.SEVERE, null, ex);
                }      
            });
            
            writer.close();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args)
    {
        Anagrams anagram = new Anagrams();
        anagram.run();
    }
}
